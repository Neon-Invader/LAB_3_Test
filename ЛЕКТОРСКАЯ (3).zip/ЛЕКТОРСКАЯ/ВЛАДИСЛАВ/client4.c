#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <pwd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "libmysyslog.h"

#define BUFFER_SIZE 1024
#define LOG_PATH "/var/log/myrpc.log"
#define MIN_PORT 1024
#define MAX_PORT 65535

typedef struct {
    char* command;
    char* server_ip;
    int port;
    int use_tcp;
} ClientOptions;

void show_help() {
    printf("Remote Command Client\n");
    printf("Usage: rpc_client [OPTIONS]\n");
    printf("Options:\n");
    printf("  -c, --command CMD    Command to execute on server\n");
    printf("  -h, --host IP        Server IP address\n");
    printf("  -p, --port PORT      Server port (%d-%d)\n", MIN_PORT, MAX_PORT);
    printf("  -s, --stream         Use TCP (default)\n");
    printf("  -d, --dgram          Use UDP\n");
    printf("      --help           Show this help\n");
}

int parse_args(int argc, char *argv[], ClientOptions *opts) {
    opts->use_tcp = 1;
    
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            if (strcmp(argv[i], "-c") == 0 || strcmp(argv[i], "--command") == 0) {
                if (i + 1 >= argc) {
                    fprintf(stderr, "Error: Missing argument for command\n");
                    return -1;
                }
                opts->command = argv[++i];
            }
            else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--host") == 0) {
                if (i + 1 >= argc) {
                    fprintf(stderr, "Error: Missing argument for host\n");
                    return -1;
                }
                opts->server_ip = argv[++i];
            }
            else if (strcmp(argv[i], "-p") == 0 || strcmp(argv[i], "--port") == 0) {
                if (i + 1 >= argc) {
                    fprintf(stderr, "Error: Missing argument for port\n");
                    return -1;
                }
                opts->port = atoi(argv[++i]);
                if (opts->port < MIN_PORT || opts->port > MAX_PORT) {
                    fprintf(stderr, "Port must be between %d and %d\n", MIN_PORT, MAX_PORT);
                    return -1;
                }
            }
            else if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "--stream") == 0) {
                opts->use_tcp = 1;
            }
            else if (strcmp(argv[i], "-d") == 0 || strcmp(argv[i], "--dgram") == 0) {
                opts->use_tcp = 0;
            }
            else if (strcmp(argv[i], "--help") == 0) {
                show_help();
                return 1;
            }
            else {
                fprintf(stderr, "Unknown option: %s\n", argv[i]);
                return -1;
            }
        }
    }

    if (!opts->command || !opts->server_ip || !opts->port) {
        fprintf(stderr, "Missing required arguments\n");
        show_help();
        return -1;
    }
    return 0;
}

int setup_socket(int use_tcp) {
    int sock;
    if (use_tcp) {
        sock = socket(AF_INET, SOCK_STREAM, 0);
    } else {
        sock = socket(AF_INET, SOCK_DGRAM, 0);
    }
    
    if (sock < 0) {
        mysyslog("Socket creation error", ERROR, 0, 0, LOG_PATH);
        perror("socket");
    }
    return sock;
}

int connect_tcp(int sock, struct sockaddr_in *addr) {
    if (connect(sock, (struct sockaddr*)addr, sizeof(*addr))) {
        mysyslog("TCP connection error", ERROR, 0, 0, LOG_PATH);
        perror("connect");
        return -1;
    }
    mysyslog("TCP connected", INFO, 0, 0, LOG_PATH);
    return 0;
}

void send_request(int sock, const char *request, struct sockaddr_in *addr, int use_tcp) {
    ssize_t sent;
    
    if (use_tcp) {
        sent = send(sock, request, strlen(request), 0);
    } else {
        sent = sendto(sock, request, strlen(request), 0, 
                     (struct sockaddr*)addr, sizeof(*addr));
    }

    if (sent == (ssize_t)strlen(request)) {
        return;
    }

    mysyslog("Send failed", ERROR, 0, 0, LOG_PATH);
    if (sent < 0) {
        perror("send");
    } else {
        perror("incomplete send");
    }
    close(sock);
    exit(EXIT_FAILURE);
}

void receive_response(int sock, char *buffer, int use_tcp) {
    ssize_t received;
    struct sockaddr_in udp_addr;
    socklen_t udp_len = sizeof(udp_addr);

    if (use_tcp) {
        received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
    } else {
        received = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0,
                          (struct sockaddr*)&udp_addr, &udp_len);
        
        if (received > 0) {
            char ip_str[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &udp_addr.sin_addr, ip_str, sizeof(ip_str));
            printf("UDP response from %s:%d\n", ip_str, ntohs(udp_addr.sin_port));
        }
    }

    if (received < 0) {
        mysyslog("Receive failed", ERROR, 0, 0, LOG_PATH);
        perror("recv");
        close(sock);
        exit(EXIT_FAILURE);
    }

    buffer[received] = '\0';
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        show_help();
        return EXIT_FAILURE;
    }

    ClientOptions opts = {0};
    int parse_result = parse_args(argc, argv, &opts);
    if (parse_result != 0) {
        return parse_result == 1 ? EXIT_SUCCESS : EXIT_FAILURE;
    }

    struct passwd *pw = getpwuid(getuid());
    char request[BUFFER_SIZE];
    snprintf(request, sizeof(request), "%s: %s", pw->pw_name, opts.command);

    mysyslog("Starting client", INFO, 0, 0, LOG_PATH);

    int sock = setup_socket(opts.use_tcp);
    if (sock < 0) return EXIT_FAILURE;

    struct sockaddr_in serv_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(opts.port)
    };
    
    if (inet_pton(AF_INET, opts.server_ip, &serv_addr.sin_addr) <= 0) {
        mysyslog("Invalid IP", ERROR, 0, 0, LOG_PATH);
        perror("inet_pton");
        close(sock);
        return EXIT_FAILURE;
    }

    if (opts.use_tcp && connect_tcp(sock, &serv_addr)) {
        close(sock);
        return EXIT_FAILURE;
    }

    send_request(sock, request, &serv_addr, opts.use_tcp);

    char response[BUFFER_SIZE];
    receive_response(sock, response, opts.use_tcp);

    printf("Response: %s\n", response);
    mysyslog("Received response", INFO, 0, 0, LOG_PATH);

    close(sock);
    return EXIT_SUCCESS;
}