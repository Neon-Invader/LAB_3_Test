#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <pwd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "libmysyslog.h"

#define BUFFER_SIZE 1024
#define LOG_FILE "/var/log/myrpc.log"
#define MIN_PORT 1024

void print_usage() {
    printf("Usage: rpcclient -c COMMAND -h HOST -p PORT [-s|-d]\n");
    printf("  -c, --command  Command to execute\n");
    printf("  -h, --host     Server IP\n");
    printf("  -p, --port     Server port (>= %d)\n", MIN_PORT);
    printf("  -s, --stream   Use TCP (default)\n");
    printf("  -d, --dgram    Use UDP\n");
}

int main(int argc, char *argv[]) {
    char *cmd = NULL, *host = NULL;
    int port = 0, tcp = 1, opt;
    
    while ((opt = getopt(argc, argv, "c:h:p:sd")) != -1) {
        switch (opt) {
            case 'c': cmd = optarg; break;
            case 'h': host = optarg; break;
            case 'p': port = atoi(optarg); break;
            case 's': tcp = 1; break;
            case 'd': tcp = 0; break;
            default: print_usage(); return 1;
        }
    }

    if (!cmd || !host || port < MIN_PORT) {
        print_usage();
        return 1;
    }

    struct passwd *user = getpwuid(getuid());
    char req[BUFFER_SIZE];
    snprintf(req, sizeof(req), "%s: %s", user->pw_name, cmd);

    mysyslog("Client starting", INFO, 0, 0, LOG_FILE);

    int sock;
    if (tcp) {
        sock = socket(AF_INET, SOCK_STREAM, 0);
    } else {
        sock = socket(AF_INET, SOCK_DGRAM, 0);
    }

    if (sock < 0) {
        perror("socket");
        mysyslog("Socket error", ERROR, 0, 0, LOG_FILE);
        return 1;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(port)
    };
    inet_pton(AF_INET, host, &addr.sin_addr);

    if (tcp) {
        if (connect(sock, (struct sockaddr*)&addr, sizeof(addr))) {
            perror("connect");
            mysyslog("Connect failed", ERROR, 0, 0, LOG_FILE);
            close(sock);
            return 1;
        }
    }

    if (tcp) {
        send(sock, req, strlen(req), 0);
    } else {
        sendto(sock, req, strlen(req), 0, (struct sockaddr*)&addr, sizeof(addr));
    }

    char resp[BUFFER_SIZE];
    ssize_t len;
    
    if (tcp) {
        len = recv(sock, resp, sizeof(resp) - 1, 0);
    } else {
        len = recvfrom(sock, resp, sizeof(resp) - 1, 0, NULL, NULL);
    }

    if (len < 0) {
        perror("recv");
        mysyslog("Receive error", ERROR, 0, 0, LOG_FILE);
        close(sock);
        return 1;
    }

    resp[len] = '\0';
    printf("Response: %s\n", resp);
    mysyslog("Got response", INFO, 0, 0, LOG_FILE);

    close(sock);
    return 0;
}