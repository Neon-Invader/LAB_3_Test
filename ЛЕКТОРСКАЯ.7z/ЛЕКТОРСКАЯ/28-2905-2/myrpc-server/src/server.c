#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pwd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include "config_parser.h"
#include "libmysyslog.h"

#define BUFFER_SIZE 1024
#define MAX_USERS 32
#define CONFIG_PATH "/etc/myRPC/server.conf"
#define USERS_PATH "/etc/myRPC/allowed_users.conf"
#define LOG_PATH "/var/log/myrpc.log"

volatile sig_atomic_t stop;

void handle_signal(int sig) {
    stop = 1;
}

typedef struct {
    char users[MAX_USERS][32];
    int count;
} UserList;

int load_users(UserList *list) {
    FILE *file = fopen(USERS_PATH, "r");
    if (!file) {
        mysyslog("Cannot open users file", ERROR, 0, 0, LOG_PATH);
        return 0;
    }

    char line[64];
    list->count = 0;

    while (fgets(line, sizeof(line), file) && list->count < MAX_USERS) {
        line[strcspn(line, "\n")] = 0;
        
        if (line[0] == '#' || line[0] == '\0') {
            continue;
        }

        strncpy(list->users[list->count], line, 31);
        list->users[list->count][31] = '\0';
        list->count++;
    }

    fclose(file);
    return 1;
}

int is_user_allowed(const UserList *list, const char *username) {
    for (int i = 0; i < list->count; i++) {
        if (strcmp(list->users[i], username) == 0) {
            return 1;
        }
    }
    return 0;
}

int create_temp_file(char *template) {
    int fd = mkstemp(template);
    if (fd < 0) {
        mysyslog("Temp file creation failed", ERROR, 0, 0, LOG_PATH);
        return -1;
    }
    close(fd);
    return 0;
}

int execute_and_capture(const char *command, char *output, size_t max_len) {
    char stdout_file[] = "/tmp/myRPC_XXXXXX";
    if (create_temp_file(stdout_file) != 0) {
        return -1;
    }

    char cmd[BUFFER_SIZE];
    snprintf(cmd, BUFFER_SIZE, "%s >%s 2>&1", command, stdout_file);
    
    int ret = system(cmd);
    if (ret != 0) {
        remove(stdout_file);
        return -1;
    }

    FILE *f = fopen(stdout_file, "r");
    if (!f) {
        remove(stdout_file);
        return -1;
    }

    size_t read = fread(output, 1, max_len - 1, f);
    output[read] = '\0';
    fclose(f);
    remove(stdout_file);

    return 0;
}

int setup_server_socket(int port, int is_stream) {
    int sock_type;
    if (is_stream) {
        sock_type = SOCK_STREAM;
    } else {
        sock_type = SOCK_DGRAM;
    }

    int sockfd = socket(AF_INET, sock_type, 0);
    if (sockfd < 0) {
        mysyslog("Socket creation failed", ERROR, 0, 0, LOG_PATH);
        return -1;
    }

    int opt = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        close(sockfd);
        mysyslog("setsockopt failed", ERROR, 0, 0, LOG_PATH);
        return -1;
    }

    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(port);

    if (bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        close(sockfd);
        mysyslog("Bind failed", ERROR, 0, 0, LOG_PATH);
        return -1;
    }

    if (is_stream) {
        if (listen(sockfd, 5) < 0) {
            close(sockfd);
            mysyslog("Listen failed", ERROR, 0, 0, LOG_PATH);
            return -1;
        }
    }

    return sockfd;
}

void process_stream_request(int connfd, const UserList *users) {
    char buffer[BUFFER_SIZE];
    int n = recv(connfd, buffer, BUFFER_SIZE, 0);

    if (n <= 0) {
        return;
    }

    buffer[n] = '\0';
    mysyslog("Request received", INFO, 0, 0, LOG_PATH);

    char *username = strtok(buffer, ":");
    char *command = strtok(NULL, "\0");
    
    char response[BUFFER_SIZE];
    if (!username || !command) {
        const char *err = "2: Invalid request format";
        send(connfd, err, strlen(err), 0);
        return;
    }

    if (!is_user_allowed(users, username)) {
        snprintf(response, BUFFER_SIZE, "1: Access denied for '%s'", username);
        mysyslog("Access denied", WARN, 0, 0, LOG_PATH);
    } else {
        if (execute_and_capture(command, response, BUFFER_SIZE) != 0) {
            strcpy(response, "3: Command execution failed");
            mysyslog("Command failed", ERROR, 0, 0, LOG_PATH);
        } else {
            mysyslog("Command executed", INFO, 0, 0, LOG_PATH);
        }
    }

    send(connfd, response, strlen(response), 0);
}

void process_datagram_request(int sockfd, const UserList *users) {
    struct sockaddr_in cliaddr;
    socklen_t len = sizeof(cliaddr);
    char buffer[BUFFER_SIZE];
    
    int n = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&cliaddr, &len);
    if (n <= 0) {
        return;
    }

    buffer[n] = '\0';
    mysyslog("Request received", INFO, 0, 0, LOG_PATH);

    char *username = strtok(buffer, ":");
    char *command = strtok(NULL, "\0");
    
    char response[BUFFER_SIZE];
    if (!username || !command) {
        const char *err = "2: Invalid request format";
        sendto(sockfd, err, strlen(err), 0, (struct sockaddr*)&cliaddr, len);
        return;
    }

    if (!is_user_allowed(users, username)) {
        snprintf(response, BUFFER_SIZE, "1: Access denied for '%s'", username);
        mysyslog("Access denied", WARN, 0, 0, LOG_PATH);
    } else {
        if (execute_and_capture(command, response, BUFFER_SIZE) != 0) {
            strcpy(response, "3: Command execution failed");
            mysyslog("Command failed", ERROR, 0, 0, LOG_PATH);
        } else {
            mysyslog("Command executed", INFO, 0, 0, LOG_PATH);
        }
    }

    sendto(sockfd, response, strlen(response), 0, (struct sockaddr*)&cliaddr, len);
}

int main() {
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);

    Config config = parse_config(CONFIG_PATH);
    if (config.port == 0) {
        mysyslog("Invalid configuration", ERROR, 0, 0, LOG_PATH);
        return 1;
    }

    UserList users;
    if (!load_users(&users)) {
        return 1;
    }

    int is_stream = strcmp(config.socket_type, "stream") == 0;
    int sockfd = setup_server_socket(config.port, is_stream);
    if (sockfd < 0) {
        return 1;
    }

    if (is_stream) {
        mysyslog("Stream server started", INFO, 0, 0, LOG_PATH);
    } else {
        mysyslog("Datagram server started", INFO, 0, 0, LOG_PATH);
    }

    while (!stop) {
        if (is_stream) {
            struct sockaddr_in cliaddr;
            socklen_t len = sizeof(cliaddr);
            int connfd = accept(sockfd, (struct sockaddr*)&cliaddr, &len);
            if (connfd < 0) {
                continue;
            }
            
            process_stream_request(connfd, &users);
            close(connfd);
        } else {
            process_datagram_request(sockfd, &users);
        }
    }

    close(sockfd);
    mysyslog("Server stopped", INFO, 0, 0, LOG_PATH);
    return 0;
}
