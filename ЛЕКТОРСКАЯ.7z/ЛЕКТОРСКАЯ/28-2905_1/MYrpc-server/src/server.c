#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pwd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include "config_parser.h"
#include "libmysyslog.h"

#define BUFFER_SIZE 1024
#define MAIN_CONFIG "/etc/myRPC/myRPC.conf"
#define USERS_CONFIG "/etc/myRPC/users.conf"
#define LOG_FILE "/var/log/myrpc.log"
#define TEMPLATE_STDOUT "/tmp/myRPC_XXXXXX.stdout"
#define TEMPLATE_STDERR "/tmp/myRPC_XXXXXX.stderr"

volatile sig_atomic_t stop;

void handle_signal(int sig) {
    stop = 1;
}

int user_allowed(const char *username) {
    Config config = parse_config(USERS_CONFIG);
    
    // Проверка основного пользователя
    if (strlen(config.user) > 0 && strcmp(config.user, username) == 0)
        return 1;
    
    // Проверка дополнительных пользователей
    for (size_t i = 0; i < config.users_count; i++) {
        if (strcmp(config.users[i], username) == 0)
            return 1;
    }
    
    return 0;
}

int execute_command(const char *command, char *response, size_t response_size) {
    char stdout_path[sizeof(TEMPLATE_STDOUT)];
    char stderr_path[sizeof(TEMPLATE_STDERR)];
    
    // Создаем временные файлы
    strcpy(stdout_path, TEMPLATE_STDOUT);
    strcpy(stderr_path, TEMPLATE_STDERR);
    
    int stdout_fd = mkstemp(stdout_path);
    if (stdout_fd == -1) {
        mysyslog("Failed to create stdout temp file", ERROR, 0, 0, LOG_FILE);
        return -1;
    }
    close(stdout_fd);

    int stderr_fd = mkstemp(stderr_path);
    if (stderr_fd == -1) {
        mysyslog("Failed to create stderr temp file", ERROR, 0, 0, LOG_FILE);
        remove(stdout_path);
        return -1;
    }
    close(stderr_fd);

    // Выполняем команду
    char cmd[BUFFER_SIZE];
    snprintf(cmd, BUFFER_SIZE, "%s >%s 2>%s", command, stdout_path, stderr_path);
    
    int ret = system(cmd);
    if (ret == -1) {
        mysyslog("Command execution failed", ERROR, 0, 0, LOG_FILE);
        remove(stdout_path);
        remove(stderr_path);
        return -1;
    }

    // Читаем результат
    FILE *fp = fopen(stdout_path, "r");
    if (!fp) {
        mysyslog("Failed to open stdout file", ERROR, 0, 0, LOG_FILE);
        remove(stdout_path);
        remove(stderr_path);
        return -1;
    }

    size_t read_bytes = fread(response, 1, response_size - 1, fp);
    response[read_bytes] = '\0';
    fclose(fp);

    // Удаляем временные файлы
    remove(stdout_path);
    remove(stderr_path);

    return 0;
}

int main() {
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);

    Config config = parse_config(MAIN_CONFIG);
    if (config.port <= 0 || config.port > 65535) {
        fprintf(stderr, "Invalid port: %d\n", config.port);
        return 1;
    }

    int is_stream = strcmp(config.socket_type, "stream") == 0;
    int sockfd = socket(AF_INET, is_stream ? SOCK_STREAM : SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        mysyslog("Socket creation failed", ERROR, 0, 0, LOG_FILE);
        return 1;
    }

    int opt = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt");
        mysyslog("setsockopt failed", ERROR, 0, 0, LOG_FILE);
        close(sockfd);
        return 1;
    }

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(config.port),
        .sin_addr.s_addr = INADDR_ANY
    };

    if (bind(sockfd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        mysyslog("Bind failed", ERROR, 0, 0, LOG_FILE);
        close(sockfd);
        return 1;
    }

    if (is_stream) {
        if (listen(sockfd, 5) < 0) {
            perror("listen");
            mysyslog("Listen failed", ERROR, 0, 0, LOG_FILE);
            close(sockfd);
            return 1;
        }
        mysyslog("TCP server started", INFO, 0, 0, LOG_FILE);
    } else {
        mysyslog("UDP server started", INFO, 0, 0, LOG_FILE);
    }

    while (!stop) {
        struct sockaddr_in cli_addr;
        socklen_t addr_len = sizeof(cli_addr);
        char buffer[BUFFER_SIZE];
        int connfd = sockfd;
        
        if (is_stream) {
            connfd = accept(sockfd, (struct sockaddr*)&cli_addr, &addr_len);
            if (connfd < 0) {
                mysyslog("Accept failed", ERROR, 0, 0, LOG_FILE);
                continue;
            }
        }

        ssize_t n;
        if (is_stream) {
            n = recv(connfd, buffer, BUFFER_SIZE, 0);
        } else {
            n = recvfrom(connfd, buffer, BUFFER_SIZE, 0,
                        (struct sockaddr*)&cli_addr, &addr_len);
        }
        
        if (n <= 0) {
            if (is_stream) close(connfd);
            continue;
        }
        buffer[n] = '\0';
        
        char *username = strtok(buffer, ":");
        char *command = strtok(NULL, "");
        if (!username || !command) {
            mysyslog("Invalid request format", WARN, 0, 0, LOG_FILE);
            if (is_stream) close(connfd);
            continue;
        }

        char response[BUFFER_SIZE] = {0};
        if (user_allowed(username)) {
            if (execute_command(command, response, sizeof(response))) {
                strcpy(response, "Command execution failed");
            }
        } else {
            snprintf(response, sizeof(response), "Access denied for %s", username);
            mysyslog("User not allowed", WARN, 0, 0, LOG_FILE);
        }

        if (is_stream) {
            if (send(connfd, response, strlen(response), 0) < 0) {
                mysyslog("Send failed", ERROR, 0, 0, LOG_FILE);
            }
            close(connfd);
        } else {
            if (sendto(sockfd, response, strlen(response), 0,
                     (struct sockaddr*)&cli_addr, addr_len) < 0) {
                mysyslog("Sendto failed", ERROR, 0, 0, LOG_FILE);
            }
        }
    }

    close(sockfd);
    mysyslog("Server stopped", INFO, 0, 0, LOG_FILE);
    return 0;
}
