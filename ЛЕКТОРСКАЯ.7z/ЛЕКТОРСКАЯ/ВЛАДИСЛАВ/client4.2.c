#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <pwd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "libmysyslog.h"

#define BUFFER_SIZE 1024
#define LOG_PATH "/var/log/myrpc.log"
#define MIN_PORT 1024
#define MAX_PORT 65535

typedef struct {
    char* command;
    char* server_ip;
    int port;
    int use_tcp;
} ClientOptions;

void show_help() {
    printf("Remote Command Client\n");
    printf("Usage: rpc_client [OPTIONS]\n");
    printf("Options:\n");
    printf("  -c, --command CMD    Command to execute on server\n");
    printf("  -h, --host IP        Server IP address\n");
    printf("  -p, --port PORT      Server port (%d-%d)\n", MIN_PORT, MAX_PORT);
    printf("  -s, --stream         Use TCP (default)\n");
    printf("  -d, --dgram          Use UDP\n");
    printf("      --help           Show this help\n");
}

int parse_args(int argc, char* argv[], ClientOptions* opts) {
    static struct option long_opts[] = {
        {"command", required_argument, NULL, 'c'},
        {"host", required_argument, NULL, 'h'},
        {"port", required_argument, NULL, 'p'},
        {"stream", no_argument, NULL, 's'},
        {"dgram", no_argument, NULL, 'd'},
        {"help", no_argument, NULL, 0},
        {NULL, 0, NULL, 0}
    };

    opts->use_tcp = 1; // Default to TCP

    int opt;
    while ((opt = getopt_long(argc, argv, "c:h:p:sd", long_opts, NULL)) != -1) {
        switch (opt) {
        case 'c': opts->command = optarg; break;
        case 'h': opts->server_ip = optarg; break;
        case 'p':
            opts->port = atoi(optarg);
            if (opts->port < MIN_PORT || opts->port > MAX_PORT) {
                fprintf(stderr, "Port must be between %d and %d\n", MIN_PORT, MAX_PORT);
                return -1;
            }
            break;
        case 's': opts->use_tcp = 1; break;
        case 'd': opts->use_tcp = 0; break;
        case 0: show_help(); return 1;
        default: return -1;
        }
    }

    if (!opts->command || !opts->server_ip || !opts->port) {
        fprintf(stderr, "Missing required arguments\n");
        show_help();
        return -1;
    }
    return 0;
}

int setup_socket(int use_tcp) {
    int sock;
    if (use_tcp) {
        sock = socket(AF_INET, SOCK_STREAM, 0);
    }
    else {
        sock = socket(AF_INET, SOCK_DGRAM, 0);
    }

    if (sock < 0) {
        mysyslog("Socket creation error", ERROR, 0, 0, LOG_PATH);
        perror("socket");
    }
    return sock;
}

int connect_tcp(int sock, struct sockaddr_in* addr) {
    if (connect(sock, (struct sockaddr*)addr, sizeof(*addr))) {
        mysyslog("TCP connection error", ERROR, 0, 0, LOG_PATH);
        perror("connect");
        return -1;
    }
    mysyslog("TCP connected", INFO, 0, 0, LOG_PATH);
    return 0;
}

void send_request(int sock, const char* request, struct sockaddr_in* addr, int use_tcp) {
    ssize_t sent;
    if (use_tcp) {
        sent = send(sock, request, strlen(request), 0);
    }
    else {
        sent = sendto(sock, request, strlen(request), 0,
            (struct sockaddr*)addr, sizeof(*addr));
    }

    if (sent < 0) {
        mysyslog("Send failed", ERROR, 0, 0, LOG_PATH);
        perror("send");
        close(sock);
        exit(EXIT_FAILURE);
    }
    else if (sent != (ssize_t)strlen(request)) {
        mysyslog("Send failed", ERROR, 0, 0, LOG_PATH);
        fprintf(stderr, "incomplete send\n");
        close(sock);
        exit(EXIT_FAILURE);
    }
}

void receive_response(int sock, char* buffer, int use_tcp) {
    ssize_t received;
    struct sockaddr_in udp_addr;
    socklen_t udp_len = sizeof(udp_addr);

    if (use_tcp) {
        received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
    }
    else {
        received = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0,
            (struct sockaddr*)&udp_addr, &udp_len);

        if (received > 0) {
            char ip_str[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &udp_addr.sin_addr, ip_str, sizeof(ip_str));
            printf("UDP response from %s:%d\n", ip_str, ntohs(udp_addr.sin_port));
        }
    }

    if (received < 0) {
        mysyslog("Receive failed", ERROR, 0, 0, LOG_PATH);
        perror("recv");
        close(sock);
        exit(EXIT_FAILURE);
    }

    buffer[received] = '\0';
}

int main(int argc, char* argv[]) {
    ClientOptions opts = { 0 };
    if (parse_args(argc, argv, &opts)) {
        return EXIT_FAILURE;
    }

    struct passwd* pw = getpwuid(getuid());
    char request[BUFFER_SIZE];
    snprintf(request, sizeof(request), "%s: %s", pw->pw_name, opts.command);

    mysyslog("Starting client", INFO, 0, 0, LOG_PATH);

    int sock = setup_socket(opts.use_tcp);
    if (sock < 0) return EXIT_FAILURE;

    struct sockaddr_in serv_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(opts.port)
    };

    if (inet_pton(AF_INET, opts.server_ip, &serv_addr.sin_addr) <= 0) {
        mysyslog("Invalid IP", ERROR, 0, 0, LOG_PATH);
        perror("inet_pton");
        close(sock);
        return EXIT_FAILURE;
    }

    if (opts.use_tcp && connect_tcp(sock, &serv_addr)) {
        close(sock);
        return EXIT_FAILURE;
    }

    send_request(sock, request, &serv_addr, opts.use_tcp);

    char response[BUFFER_SIZE];
    receive_response(sock, response, opts.use_tcp);

    printf("Response: %s\n", response);
    mysyslog("Received response", INFO, 0, 0, LOG_PATH);

    close(sock);
    return EXIT_SUCCESS;
}