#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pwd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include "config_parser.h"
#include "libmysyslog.h"

#define BUFFER_SIZE 2048
#define MAX_ALLOWED_USERS 64
#define MAIN_CONFIG "/etc/myRPC/main.conf"
#define USER_ACCESS_FILE "/etc/myRPC/access.conf"
#define SERVER_LOG "/var/log/myrpc.log"
#define TEMP_FILE_TEMPLATE "/tmp/myrpc_out_XXXXXX"

static volatile sig_atomic_t keep_running = 1;

void signal_handler(int sig) {
    keep_running = 0;
}

typedef struct {
    char allowed_users[MAX_ALLOWED_USERS][32];
    int user_count;
} AccessControl;

int initialize_access_control(AccessControl* ac) {
    FILE* file = fopen(USER_ACCESS_FILE, "r");
    if (!file) {
        mysyslog("Could not open access control file", ERROR, 0, 0, SERVER_LOG);
        return 0;
    }

    char line[64];
    ac->user_count = 0;

    while (fgets(line, sizeof(line), file && ac->user_count < MAX_ALLOWED_USERS)) {
        line[strcspn(line, "\n")] = 0;
        if (line[0] != '#' && line[0] != '\0') {
            strncpy(ac->allowed_users[ac->user_count], line, 31);
            ac->allowed_users[ac->user_count][31] = '\0';
            ac->user_count++;
        }
    }

    fclose(file);
    return 1;
}

int check_user_permission(const AccessControl* ac, const char* username) {
    for (int i = 0; i < ac->user_count; i++) {
        if (strcmp(ac->allowed_users[i], username) == 0) {
            return 1;
        }
    }
    return 0;
}

int run_command(const char* command, char* output, size_t output_size) {
    char temp_file[sizeof(TEMP_FILE_TEMPLATE) + 1];
    strcpy(temp_file, TEMP_FILE_TEMPLATE);

    int fd = mkstemp(temp_file);
    if (fd < 0) {
        mysyslog("Failed to create temporary file", ERROR, 0, 0, SERVER_LOG);
        return 0;
    }
    close(fd);

    char full_command[BUFFER_SIZE];
    snprintf(full_command, BUFFER_SIZE, "%s > %s 2>&1", command, temp_file);

    int result = system(full_command);
    if (result != 0) {
        remove(temp_file);
        return 0;
    }

    FILE* f = fopen(temp_file, "r");
    if (!f) {
        remove(temp_file);
        return 0;
    }

    size_t bytes_read = fread(output, 1, output_size - 1, f);
    output[bytes_read] = '\0';
    fclose(f);
    remove(temp_file);

    return 1;
}

int create_server_socket(int port, int use_tcp) {
    int socket_type;
    if (use_tcp) {
        socket_type = SOCK_STREAM;
    }
    else {
        socket_type = SOCK_DGRAM;
    }

    int sock = socket(AF_INET, socket_type, 0);
    if (sock < 0) {
        mysyslog("Socket creation error", ERROR, 0, 0, SERVER_LOG);
        return -1;
    }

    int opt = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        close(sock);
        mysyslog("Socket option setting failed", ERROR, 0, 0, SERVER_LOG);
        return -1;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        close(sock);
        mysyslog("Bind failed", ERROR, 0, 0, SERVER_LOG);
        return -1;
    }

    if (use_tcp) {
        if (listen(sock, 5) < 0) {
            close(sock);
            mysyslog("Listen failed", ERROR, 0, 0, SERVER_LOG);
            return -1;
        }
    }

    return sock;
}

void handle_client_request(int sock, int is_tcp, const struct sockaddr_in* client_addr, socklen_t client_len, const AccessControl* ac) {
    char request[BUFFER_SIZE];
    ssize_t received;

    if (is_tcp) {
        received = recv(sock, request, BUFFER_SIZE, 0);
    }
    else {
        received = recvfrom(sock, request, BUFFER_SIZE, 0, (struct sockaddr*)client_addr, &client_len);
    }

    if (received <= 0) {
        return;
    }

    request[received] = '\0';
    mysyslog("Processing request", INFO, 0, 0, SERVER_LOG);

    char* username = strtok(request, ":");
    char* command = strtok(NULL, "");
    char response[BUFFER_SIZE];

    if (!username || !command) {
        strcpy(response, "Invalid request format");
    }
    else if (!check_user_permission(ac, username)) {
        snprintf(response, BUFFER_SIZE, "User %s not authorized", username);
        mysyslog("Unauthorized access attempt", WARN, 0, 0, SERVER_LOG);
    }
    else if (!run_command(command, response, BUFFER_SIZE)) {
        strcpy(response, "Command execution error");
        mysyslog("Command execution failed", ERROR, 0, 0, SERVER_LOG);
    }
    else {
        mysyslog("Command executed successfully", INFO, 0, 0, SERVER_LOG);
    }

    if (is_tcp) {
        send(sock, response, strlen(response), 0);
    }
    else {
        sendto(sock, response, strlen(response), 0, (struct sockaddr*)client_addr, client_len);
    }
}

int main() {
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    Config config = parse_config(MAIN_CONFIG);
    if (config.port <= 0) {
        mysyslog("Invalid port in configuration", ERROR, 0, 0, SERVER_LOG);
        return 1;
    }

    AccessControl access;
    if (!initialize_access_control(&access)) {
        return 1;
    }

    int use_tcp = strcmp(config.socket_type, "stream") == 0;
    int server_socket = create_server_socket(config.port, use_tcp);
    if (server_socket < 0) {
        return 1;
    }

    mysyslog("Server started successfully", INFO, 0, 0, SERVER_LOG);

    while (keep_running) {
        if (use_tcp) {
            struct sockaddr_in client_addr;
            socklen_t client_len = sizeof(client_addr);
            int client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
            if (client_socket < 0) {
                continue;
            }
            handle_client_request(client_socket, 1, &client_addr, client_len, &access);
            close(client_socket);
        }
        else {
            handle_client_request(server_socket, 0, NULL, 0, &access);
        }
    }

    close(server_socket);
    mysyslog("Server shutdown", INFO, 0, 0, SERVER_LOG);
    return 0;
}
